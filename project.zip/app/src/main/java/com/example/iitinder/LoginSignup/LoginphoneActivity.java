package com.example.iitinder.LoginSignup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.iitinder.R;

public class LoginphoneActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginphone);
    }
}